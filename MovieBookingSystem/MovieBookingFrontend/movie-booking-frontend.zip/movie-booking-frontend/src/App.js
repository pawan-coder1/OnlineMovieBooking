import React, { useState, useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import RegisterPage from "./pages/RegisterPage";
import LoginPage from "./pages/LoginPage";
import Dashboard from "./pages/Dashboard";

function App() {
  const [userId, setUserId] = useState(null);
  const [hasRegistered, setHasRegistered] = useState(null); // null = unknown, true/false = known

  useEffect(() => {
    const storedUserId = localStorage.getItem("userId");
    const registered = localStorage.getItem("registered") === "true";

    if (storedUserId) setUserId(storedUserId);
    setHasRegistered(registered);
  }, []);

  // Wait until we know registration state
  if (hasRegistered === null) return null; // or loading spinner

  return (
    <Routes>
      {/* Default route */}
      <Route
        path="/"
        element={
          userId
            ? <Navigate to="/dashboard" />
            : hasRegistered
              ? <Navigate to="/login" />
              : <Navigate to="/register" />
        }
      />

      {/* Registration page */}
      <Route
        path="/register"
        element={userId ? <Navigate to="/dashboard" /> : <RegisterPage />}
      />

      {/* Login page */}
      <Route
        path="/login"
        element={userId ? <Navigate to="/dashboard" /> : <LoginPage setUserId={setUserId} />}
      />

      {/* Protected Dashboard */}
      <Route
        path="/dashboard"
        element={userId ? <Dashboard userId={userId} setUserId={setUserId} /> : <Navigate to="/login" />}
      />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}

export default App;
