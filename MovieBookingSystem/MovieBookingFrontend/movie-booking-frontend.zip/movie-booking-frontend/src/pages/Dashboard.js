import React, { useState } from "react";
import MovieList from "../components/MovieList";
import ShowtimeList from "../components/ShowtimeList";
import BookingForm from "../components/BookingForm";
import BookingList from "../components/BookingList";

const Dashboard = ({ userId }) => {
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [selectedShowtime, setSelectedShowtime] = useState(null);

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="flex justify-end mb-4">
        <button className="bg-gray-700 text-white px-4 py-2 rounded hover:bg-gray-800"
          onClick={() => {
            localStorage.removeItem("token");
            localStorage.removeItem("userId");
            window.location.reload();
          }}>
          Logout
        </button>
      </div>

      {!selectedMovie && <MovieList selectMovie={setSelectedMovie} />}
      {selectedMovie && !selectedShowtime && <ShowtimeList movie={selectedMovie} selectShowtime={setSelectedShowtime} />}
      {selectedShowtime && <BookingForm showtime={selectedShowtime} userId={userId} onBookingSuccess={() => setSelectedShowtime(null)} />}
      
      <BookingList userId={userId} />
    </div>
  );
};

export default Dashboard;
