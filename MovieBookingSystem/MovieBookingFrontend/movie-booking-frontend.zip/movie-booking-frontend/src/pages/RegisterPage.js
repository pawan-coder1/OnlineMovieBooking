import React from "react";
import RegisterForm from "../components/RegisterForm";
import { useNavigate } from "react-router-dom";

const RegisterPage = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <RegisterForm onRegisterSuccess={() => navigate("/login")} />
    </div>
  );
};

export default RegisterPage;
