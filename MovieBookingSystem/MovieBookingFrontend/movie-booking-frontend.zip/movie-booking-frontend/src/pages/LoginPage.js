import React from "react";
import LoginForm from "../components/LoginForm";
import { useNavigate } from "react-router-dom";

const LoginPage = ({ setUserId }) => {
  const navigate = useNavigate();

  const handleLoginSuccess = (uid) => {
    setUserId(uid);
    localStorage.setItem("userId", uid);
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <LoginForm onLoginSuccess={handleLoginSuccess} />
    </div>
  );
};

export default LoginPage;
