import axios from "axios";

const API_URL = "https://localhost:7275/api";

// Auth
export const registerUser = (data) => axios.post(`${API_URL}/Auth/register`, data);
export const loginUser = (data) => axios.post(`${API_URL}/Auth/login`, data);

// Public endpoints
export const getMovies = () => axios.get(`${API_URL}/Movie`);
export const getShowtimes = () => axios.get(`${API_URL}/Showtime`);

// Auth headers
const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  return { Authorization: `Bearer ${token}` };
};

// Protected endpoints
export const getUserBookings = (userId) => axios.get(`${API_URL}/Booking/user/${userId}`, { headers: getAuthHeaders() });
export const createBooking = (data) => axios.post(`${API_URL}/Booking`, data, { headers: getAuthHeaders() });
export const cancelBooking = (id) => axios.delete(`${API_URL}/Booking/${id}`, { headers: getAuthHeaders() });
