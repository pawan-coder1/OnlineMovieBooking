import React, { useEffect, useState } from "react";
import { getUserBookings, cancelBooking } from "../services/api";

const BookingList = ({ userId }) => {
  const [bookings, setBookings] = useState([]);

  const fetchBookings = () => {
    getUserBookings(userId).then(res => setBookings(res.data)).catch(err => console.log(err));
  };

  useEffect(() => { fetchBookings(); }, [userId]);

  const handleCancel = async (id) => {
    try {
      await cancelBooking(id);
      fetchBookings();
      alert("Booking cancelled");
    } catch {
      alert("Failed to cancel booking");
    }
  };

  if (!bookings.length) return <p className="text-center mt-6">No bookings yet</p>;

  return (
    <div className="mt-6 max-w-2xl mx-auto">
      <h2 className="text-xl font-bold mb-4">Your Bookings</h2>
      <div className="space-y-4">
        {bookings.map(b => (
          <div key={b.id} className="bg-white shadow rounded p-4 flex justify-between items-center">
            <div>
              <p><strong>{b.showtime.movie.title}</strong> ({b.showtime.theater})</p>
              <p>Seats: {b.seats}</p>
              <p>Start: {new Date(b.showtime.startTime).toLocaleString()}</p>
            </div>
            <button className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600" onClick={() => handleCancel(b.id)}>Cancel</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BookingList;
