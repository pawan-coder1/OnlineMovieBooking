import React, { useEffect, useState } from "react";
import { getShowtimes } from "../services/api";

const ShowtimeList = ({ movie, selectShowtime }) => {
  const [showtimes, setShowtimes] = useState([]);

  useEffect(() => {
    getShowtimes().then(res => {
      const filtered = res.data.filter(s => s.movie.id === movie.id);
      setShowtimes(filtered);
    }).catch(err => console.log(err));
  }, [movie]);

  if (!showtimes.length) return <p className="text-center mt-4">No showtimes available</p>;

  return (
    <div className="mt-6">
      <h2 className="text-xl font-bold mb-4">Showtimes for {movie.title}</h2>
      <div className="space-y-4">
        {showtimes.map(show => (
          <div key={show.id} className="bg-white shadow rounded p-4 flex justify-between items-center">
            <div>
              <p className="font-semibold">{show.theater}</p>
              <p>{new Date(show.startTime).toLocaleString()}</p>
            </div>
            <button className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600" onClick={() => selectShowtime(show)}>Book</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ShowtimeList;
