import React, { useEffect, useState } from "react";
import { getMovies } from "../services/api";

const MovieList = ({ selectMovie }) => {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    getMovies().then(res => setMovies(res.data)).catch(err => console.log(err));
  }, []);

  if (!movies.length) return <p className="text-center mt-10">No movies available</p>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
      {movies.map(movie => (
        <div key={movie.id} className="bg-white shadow rounded p-4">
          <h3 className="text-xl font-bold">{movie.title}</h3>
          <p className="text-gray-600">{movie.genre} | {movie.durationMinutes} min</p>
          <button className="mt-2 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600" onClick={() => selectMovie(movie)}>Select</button>
        </div>
      ))}
    </div>
  );
};

export default MovieList;
