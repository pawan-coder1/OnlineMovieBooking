import React, { useState } from "react";
import { createBooking } from "../services/api";

const BookingForm = ({ showtime, userId, onBookingSuccess }) => {
  const [seats, setSeats] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const seatsArray = seats.split(',').map(s => s.trim().toUpperCase());
    try {
      await createBooking({ showtimeId: showtime.id, userId, seats: seatsArray });
      alert("Booking successful!");
      setSeats("");
      onBookingSuccess();
    } catch (err) {
      alert(err.response?.data || "Booking failed");
    }
  };

  return (
    <div className="max-w-md mx-auto mt-6 p-6 bg-white shadow rounded">
      <h3 className="text-xl font-bold mb-2">Book Seats for {showtime.movie.title}</h3>
      <p className="text-gray-600">Theater: {showtime.theater}</p>
      <p className="text-gray-600 mb-4">Start Time: {new Date(showtime.startTime).toLocaleString()}</p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          className="w-full p-2 border rounded"
          type="text"
          placeholder="Enter seats (e.g., A1,A2)"
          value={seats}
          onChange={e => setSeats(e.target.value)}
          required
        />
        <button className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700" type="submit">Book</button>
      </form>
    </div>
  );
};

export default BookingForm;
